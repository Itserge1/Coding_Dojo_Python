SELECT* FROM ninjas

