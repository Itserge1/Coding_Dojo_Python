from flask import Flask,render_template,request,redirect,session
from flask.globals import session
from userinfo import Userinfo

app = Flask(__name__)
# app.secret_key = "keepitsecret"

@app.route("/")
def create():
    return render_template("create.html")

@app.route("/prossec", methods=["POST"])
def prossec():
    data = {
        "first_name": request.form["fist_name"],
        "last_name": request.form["last_name"],
        "email":request.form["email"],
    }
    Userinfo.insert_userinfo(data)
    # session["fist_name"] = request.form["fist_name"]
    # session["last_name"] = request.form["last_name"]
    # session["email"] = request.form["email"]
    return redirect("/read")

@app.route("/read")
def read():
    users = Userinfo.readalluser()
    return render_template("read.html", Users = users)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port= 5001, debug=True)