from mysqlconnection import connectToMySQL

class Userinfo:
    def __init__(self,data):
        self.id = data["id"]
        self.first_name = data["first_name"]
        self.last_name = data["last_name"]
        self.email = data["email"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
    @classmethod
    def insert_userinfo(cls,data):
        query = "INSERT INTO Users (first_name,last_name,email) VALUES (%(first_name)s, %(last_name)s, %(email)s)"
        return connectToMySQL("userscr_db").query_db(query,data)
    @classmethod
    def readalluser(cls):
        query = "SELECT * FROM Users ORDER BY id DESC"
        db_users = connectToMySQL("userscr_db").query_db(query)
        Users = []

        for user in db_users:
            Users.append(Userinfo(user))

        return Users
